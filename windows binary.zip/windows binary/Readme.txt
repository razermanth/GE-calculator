All the function source code is in Source folder,

Program can be run by main.exe