# Importing Library
from unicodedata import name
import matrixCalculator as mc
import inputFileinterpreter as fi
import terminalPrinter as tp
import numpy as np
import matrixFormatConverter as converter
import sys
import latex as l

# flag for triggering new file
newFileFlag = True

# init new file > for "savefile" button 
def newFile():
    newFileFlag = True
    # add save file here
    l.sublatex(newFileFlag)

# save file > reset the pylatex 
def saveFile():
    # add save file here
    l.mainlatex(newFileFlag)
    pass
# close program > add save file here
def exitProgram():
    # add save file here
    l.mainlatex(newFileFlag)
    sys.exit()

# function that execute output > add output intrepeter here
def getOutput(n,a):
    # convert argument matrix into python array
    aPythonArray = converter.numpyToPython(a)

    #get data from matrixcalculator
    divideZero, x_geText, x_geMatrix, x_bac, x_sol=mc.matrixCalc(n,a)
    
    # add output generator here
    l.mainlatex(newFileFlag)
    l.latexMiddle(divideZero, aPythonArray, x_geText, x_geMatrix, x_bac, x_sol,n,a)
    #pass it to terminalPrinter to print on terminal
    tp.terminalPrinter(divideZero, aPythonArray, x_geText, x_geMatrix, x_bac, x_sol)
    #pass it to terminalPrinter to save on txt file
    #tp.txtPrinter(divideZero, a, x_geText, x_geMatrix, x_bac, x_sol)

    # set flag
    newFileFlag = True
    
# function that execute output from opening a file
def inputFile(data):
    errorFlag, nSet, aPythonArraySet = fi.openFile(data)

    counter = 0
    if errorFlag == False:
        for i in nSet:
            getOutput(nSet[counter],converter.pythonToNumpy(aPythonArraySet[counter]))
            counter+=1
    # report status back
    return errorFlag
    
# function that execute output from default parameters of randomizer
def inputRandomDefault():
    n,a = mc.randomizer()
    getOutput(n, a)

# function that random with config parameters
def inputRandom(nInputRandom,aInputRandom ,bInputRandom):
    n,a = mc.randomizer(nInputRandom,aInputRandom ,bInputRandom)
    getOutput(n, a)



