# Import the required library
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from tkinter import filedialog 
# communicate with the rest of program with this module
import inputOutputMethodAPI as mainAPI

# icon filepath
# icon = 'icon.ico'

# Create root windows tkinter instance
root=Tk()
# Set the geometry
root.geometry("300x400")
# Set title
root.title("GE Calculator")
# icon
# root.iconbitmap(icon)

# ---------message box---------
# successful dialog
def successfulDoneTK():
   messagebox.showinfo("Operation completed", "the order has been executed")

# cancelled dailog
def cancelledDoneTK():
    messagebox.showinfo("Operation stopped", "the order has been cancelled")

# error backend
def backendError():
    messagebox.showerror("An Error has occurred", "Cannot communicate with backend")

# error of importfile
def fileExplorerError():
    messagebox.showerror("An Error has occurred", "Invalid Input file")


# ---------import file---------
# popup window that show correct format of import file
def fileExplorerTutorialTK():
    # create window
    fileTutorial = Toplevel(root)
    fileTutorial.title('Input Example')
    fileTutorial.geometry('300x450')
    # fileTutorial.iconbitmap(icon)
    Label(fileTutorial,text="file extension: .txt", font=100).pack(pady=10)
    ttk.Button(fileTutorial, text = "Close", command=fileTutorial.destroy).pack(pady=10)
    Label(fileTutorial,text="accept multiple inputs", font=80).pack(pady=10)
    Label(fileTutorial,text="end each inputs end with 'n'", font=100).pack(pady=10)
    # example input in textfield nameed 'text'
    text = Text(fileTutorial)
    textContent="1 2 3"+"\n"+"2 6 4"+"\n"+"4 5 3"+"\n"+"n"+"\n"+"4 5 6 8"+"\n"+"3 6 8 4"+"\n"+"4 5 3 2"+"\n"+"7 5 3 6"+"\n"+"n"+"\n"+"4 5 9 8 6"+"\n"+"8 6 3 2 1"+"\n"+"6 9 5 3 2"+"\n"+"7 5 3 6 9"+"\n"+"n"+"\n"
    text.insert(INSERT, textContent)
    text.pack(pady=10)


# open file explorer for openFile()
def fileExplorerTK():
    try:
        # get file data
        filepath = filedialog.askopenfilename(title = "Import an input file" , filetypes=(("Text Files","*.txt"),("All File","*.*")))
        f = open(filepath,"r")
        data = f.read()
        f.close()
        # call module
        errorflag = mainAPI.inputFile(data)
        # report status
        if errorflag == False:
            successfulDoneTK()
        else:
            fileExplorerError()
    except:
        cancelledDoneTK()


# ---------random---------
# run random with default parameter
def randomDefaultTK():
    mainAPI.inputRandomDefault()
    successfulDoneTK()


# run random with custom parameter
def randomCustomTK():

    # recieve data from textfield
    def randomCustomInput():
        try:
            # get data
            n=inputN.get("1.0", "end-1c")
            a=inputA.get("1.0", "end-1c")
            b=inputB.get("1.0", "end-1c")
            # send data
            randomCustomLogic(n, a, b)      
        except:
            messagebox.showerror("An Error has occurred", "Some input parameters not found")
        # keep this windows on top after close popup
        randomCustom.lift()

    # create window
    randomCustom = Toplevel(root)
    randomCustom.title("Custom Parameters random")
    randomCustom.geometry('300x350')
    # remove some buttons in titlebar
    randomCustom.attributes("-toolwindow", 1)

    # elements in window
    # label n
    Label(randomCustom,text="random n x n+1 size matrix", font=100).pack(pady=10)
    # input n textfield
    inputN = Text(randomCustom,height = 1,width = 5)
    inputN.insert(INSERT, 3)
    inputN.pack(pady=10)
    # label a
    Label(randomCustom,text="each number random started from", font=100).pack(pady=10)
    # input a textfield
    inputA = Text(randomCustom,height = 1,width = 5)
    inputA.insert(INSERT, 1)
    inputA.pack(pady=10)
    # label b
    Label(randomCustom,text="to", font=100).pack()
    # input b textfield
    inputB = Text(randomCustom,height = 1,width = 5)
    inputB.insert(INSERT, 20)
    inputB.pack(pady=10)
    # buttons
    ttk.Button(randomCustom, text="Execute order", command=randomCustomInput).pack(pady=10)
    ttk.Button(randomCustom, text="Close", command=randomCustom.destroy).pack(pady=10)

# send data from randomCustomWindows() to module api
def randomCustomLogic(n, a, b):
    # check inputs
    if PrimitiveChecker(n)!=0:
        messagebox.showerror("An Error has occurred", "Input n is not an integer")
    elif PrimitiveChecker(a)==2:
        messagebox.showerror("An Error has occurred", "Input a is not a number")
    elif PrimitiveChecker(b)==2:
        messagebox.showerror("An Error has occurred", "Input b is not a number")
    elif float(a) >= float(b):
        messagebox.showerror("An Error has occurred", "Input a must be smaller that input b")
    else:
        # send data to api module
        try:
            mainAPI.inputRandom(int(n),float(a),float(b))
            successfulDoneTK()
        except:
            backendError()

# int,float,string checker. used by randomCustomLogic()
def PrimitiveChecker(inputVariable):
    if inputVariable.isdigit():
        # Integer
        return 0
    elif inputVariable.replace('.','',1).isdigit() and inputVariable.count('.') < 2:
        # Float
        return 1
    else:
        # Something else
        return 2



def AboutPage():
    # create subwindow
    aboutPage = Toplevel(root)
    # name in titlebar
    aboutPage.title('About')
    # window size
    aboutPage.geometry('510x600')
    # remove some buttons in titlebar
    aboutPage.attributes("-toolwindow", 1)
    ttk.Button(aboutPage, text = "Close", command=aboutPage.destroy).pack(pady=10)
    Label(aboutPage,text="this program is part of Senior Project: SM1-2021", font=100).pack(pady=10)
    Label(aboutPage,text="Sirindhorn International Institute of Technology", font=100).pack(pady=10)
    Label(aboutPage,text="Thammasat University", font=100).pack(pady=10)
    Label(aboutPage,text="", font=80).pack(pady=10)
    Label(aboutPage,text="MIT License (MIT)", font=100).pack(pady=10)
    # example input in textfield nameed 'text'
    text = Text(aboutPage)
    license= "Copyright © 2022 Kunanon Siriadul,Thatchakorn Yenpensuk\n\nPermission is hereby granted, free of charge, to any person\nobtaining a copy of this software and associated documentation\nfiles (the “Software”), to deal in the Software without\nrestriction, including without limitation the rights to use,\ncopy, modify, merge, publish, distribute, sublicense, and or\n sell copies of the Software, and to permit persons to whom\nthe Software is furnished to do so, subject to the following\nconditions:\n\nThe above\ncopyright notice and this permission notice\nshall be included in all copies or substantial portions\nof the Software.\n\nTHE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,\nEXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES\nOF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND \nNONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT \nHOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, \nWHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING\nFROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE \nOR OTHER DEALINGS IN THE SOFTWARE."
    text.insert(INSERT, license)
    text.pack(pady=10)
# ---------main window elements---------
Label(root,text="Random input").pack()
ttk.Button(root, text="Default Parameters", command=randomDefaultTK).pack(pady=10)
ttk.Button(root, text="Custom Parameters", command=randomCustomTK).pack(pady=10)
Label(root,text="Import .txt file").pack()
ttk.Button(root, text="Tutorial", command=fileExplorerTutorialTK).pack(pady=10)
ttk.Button(root, text="Import a file", command=fileExplorerTK).pack(pady=10)
Label(root,text="This Software is made for educational purposes").pack()
ttk.Button(root, text="About this Program", command=AboutPage).pack(pady=10)
ttk.Button(root, text="Save File", command=mainAPI.saveFile).pack(pady=10)
ttk.Button(root, text="Save and Exit", command=mainAPI.exitProgram).pack(pady=10)
root.mainloop()
