# Importing Library
import matrixCalculator as mc
import terminalPrinter as tp
import numpy as np

# manual input from user
def manualInput():
    # recieve number of unknowns variables
    n = int(input('Enter number of variables: '))

    # Making zeros array of n x n+1 size for storing augmented matrix
    a = np.zeros((n,n+1))

    # Reading augmented matrix coefficients
    print('Enter variables of Augmented Matrix:')
    for i in range(n):
        for j in range(n+1):
            a[i][j] = float(input( 'a['+str(i)+']['+ str(j)+']='))
    # return augmented matrix
    return n,a

# main terminal ui
def output():

# output from matrixCalculator
#
# divideZero, x_geText, x_geMatrix, x_bac, x_sol
#
# divideZero, flag for divide by zero(message includeed in
# final line of GE text)
#
# GE text(double layers array, per rows, per a[i][j])
# x_geText = []
#
# GE matrix(array of matrix array)
# x_geMatrix = []
#
# back subtitution(array of text)
# x_bac = []
#
# final answer(array of text)
# x_sol = []


# w = choice selector
# a = argument matrix
# n = n x n+1 matrix
    print("\n\n---------------")
    print("link starto! - please choose your options")
    print("  1 manual input(disabled)\n  2 random\n  3 quit program")
    w=input('Enter: ')
    print("---------------")

    # choice: manual input 
    if w =='1':
        exit()
    #     n,a=manualInput()
    #     x=mc.matrixCalc(n,a)
    #     tp.terminalPrinter(a,x)
    #     tp.txtPrinter(a,x)
    #choice: random loop

    elif w=='2':
        print('default or custom parameters?\n  1 default\n  2 custom')
        w=input('Enter: ')
        print('')
        if w=='1':
            n,a=mc.randomizer()
        elif w=='2':
            print("n X n+1 matrix filled with numbers random from a to b")
            u1,u2,u3= input('Enter n a b :').split()
            n,a=mc.randomizer(int(u1),int(u2),int(u3))
        else:
            quit()
        #get data from matrixcalculator
        divideZero, x_geText, x_geMatrix, x_bac, x_sol=mc.matrixCalc(n,a)
        #pass it to terminalPrinter to print on terminal
        tp.terminalPrinter(divideZero, a, x_geText, x_geMatrix, x_bac, x_sol)
        #pass it to terminalPrinter to save on txt file
        tp.txtPrinter(divideZero, a, x_geText, x_geMatrix, x_bac, x_sol)
    
    #choice: out program
    elif w=='3':
        quit()
    else:
        print("ERROR404 please retry")
    print("---------------\noperation finished\n---------------")