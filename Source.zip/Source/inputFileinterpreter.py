import numpy as np


# for test import txt file
import matrixCalculator as mc
# python-numpy array convertor
import matrixFormatConverter as convertor

# main function
def openFile(data):
    # try building output
    errorFlag = False
    try:
        nSet, lineArraySet = examsSplit(data)
        aPythonArraySet = inputBuilder(nSet,lineArraySet)
        # test output
        mc.matrixCalc(nSet[0], convertor.pythonToNumpy(aPythonArraySet[0]))
        # call again to fix some unkown data error after running matrixCalc
        return errorFlag, nSet, aPythonArraySet

    # invalid input
    except:
        nSet = []
        aSet = []
        errorFlag = True
        # place error here
        return errorFlag, nSet, aSet

# split all line in txt into array of n and argument matrix
def examsSplit(data):
    #split into array by lines
    allLineArray = data.split('\n')

    # return array to store all data into callable array
    nSet=[]
    lineArraySet=[]
    # for keeping data of a single set of n and argument matrix
    nSingle=0
    setOfSingleArgumentMatrix=[]

    for i in allLineArray:
        # save array and n into return array
        if i == "n":
            lineArraySet.append(setOfSingleArgumentMatrix)
            nSet.append(nSingle-1)
            setOfSingleArgumentMatrix=[]
            nSingle=0
        # build array and n
        else:
            #count n
            nSingle=0
            for n in i.split():
                nSingle+=1
            setOfSingleArgumentMatrix.append(i)
    return nSet, lineArraySet



# construct array of inputs that's ready-to-use with matrixCalc 
def inputBuilder(nSet,lineArray):
    aPythonArraySet=[]
    counter = 0
    for i in nSet:
        pythonArray = convertor.numpyToPython(argumentMatrixConstructor(nSet[counter], lineArray[counter]))
        aPythonArraySet.append(pythonArray)
        counter+=1
    return aPythonArraySet

# dependency of inputBuilder() 
# turn line array into numpy array of argument matrix
def argumentMatrixConstructor(n, argumentMatrixLineArray):
    output = np.zeros((n,n+1))
    row=0
    for j in argumentMatrixLineArray:
        numbers=j.split()
        columm=0
        for i in numbers:
            output[row][columm] = int(i)
            columm+=1
        row+=1
    return output




# unused input checker
# def checkInput(nSet, aSet):
#     checkInputCounter =0
#     for i in nSet:
#         aSetCheckInputCounter=aSet[checkInputCounter]
#         checkInputCounter2=0
#         for j in nSet[checkInputCounter]:         
#             checkInputCounter3=0
#             for k in (nSet[checkInputCounter]+1):
#                 dummyCheckInput = aSetCheckInputCounter[j][k]
#             checkInputCounter3+=1
#         checkInputCounter2+=1
#     checkInputCounter+=1
# openFile(3)

# test code
# f = open("testInput.txt","r")
# errorFlag, nSet, aSet = openFile(f.read())
# print(aSet)
# f.close()