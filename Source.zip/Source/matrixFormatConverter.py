import numpy as np


# function that turn numpy array into pytho array
def numpyToPython(inputNumpyArray):
    # extract n
    # n is n x n+1
    for i in inputNumpyArray:
        # print(i)
        n=i.size-1
    # create output array
    pythonArray = []

    # inputNumpyArray[j][i]
    # j = columm
    # i = row
    # columm loop
    for j in range(0,n,1):
        # row loop
        # create single line array for storing input temp
        pythonSingleLineArrayTempStorage=[]
        for i in range(0,n+1,1):
            # use temp array to construct each row
            pythonSingleLineArrayTempStorage.append(inputNumpyArray[j][i])
        # append each row to pythonArray
        pythonArray.append(pythonSingleLineArrayTempStorage)

    # return
    return pythonArray

# function that turn python array into numpy array
def pythonToNumpy(inputPythonArray):
    # extract n
    # n is n x n+1
    for i in inputPythonArray:
        # print(len(i))
        n = len(i)-1
    
    # create output array
    numpyArray = np.zeros((n,n+1))
    

    # insert data
    for j in range(n):
        for i in range(n+1):
            numpyArray[j][i] = inputPythonArray[j][i]
    
    # return
    return numpyArray




# # test
# # default 3 x 4 matrix with random numbers from 0 to 20
# def randomizer(n = 3,a = 0 ,b = 20):
#     a = np.random.randint(a,b,size=(n, n+1))
#     # return augmented matrix
#     return n,a

# n,firstArray = randomizer(3,0,20)
# # print(firstArray.size)
# print("randomizer1:")
# print(firstArray)
# print("pythonarray1:")
# pyarray=numpyToPython(firstArray)
# print(pyarray)
# print("numpyarray1:")
# numarray = pythonToNumoy(pyarray)
# print(numarray)
# print("----------------")
# # re-run randomizer
# n,firstArray = randomizer(3,0,20)
# print("randomizer2:")
# print(firstArray)
# print("numpyarray1:")
# print(numarray)
# print("numpyarray1-position[0][0]:")
# print(numarray[0][0])