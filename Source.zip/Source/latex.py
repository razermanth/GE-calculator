from hashlib import new
from operator import ne
from subprocess import getoutput
import sys
from tkinter import N
from unicodedata import name
import numpy as np
from pylatex import Document, Section, Subsection,Command, Matrix,Math
from pylatex.utils import NoEscape,bold,make_temp_dir
import pylatex.config as cf
import os.path
import matrixCalculator as mc
import matrixFormatConverter as mf


cf.active = cf.Version1(indent=False)
geometry_options = {"tmargin": "1cm", "lmargin": "1cm", "rmargin": "1cm" }
section = Section('Matrix')
section2 = Section('Step-By-Step is:')
section3 = Section('Applying Back Substitution')
section4 = Section('Solution is:')
section5 = Section('NumpyArray is:')
subsection = Subsection('Array')

def rename(new_name):
    doc = Document(new_name,geometry_options=geometry_options)
    latexTop(doc)
    latexMiddle(doc)
    latexButtom(doc)
    #rename the file name

def mainlatex(newFileFlag):
    name = 'file'
    while newFileFlag == True:
        if newFileFlag == True:
            check(name)
            rename(name)
            print(name,'1')
            return newFileFlag
        
        elif newFileFlag == False:
            rename(name)
            print(name,'2')
            return newFileFlag
    #main function that contain all component    
def sublatex(newFileFlag):
    name = 'filex'
    doc = Document(name,geometry_options=geometry_options)
    latexTop(doc)
    if newFileFlag == True:
        latexMiddle(doc)
    doc.generate_tex()
    make_temp_dir()
    
def check(name):
    stop=100;
    for i in range(stop+1):
        if (i == 0 and not os.path.exists(name+'.tex')):
            rename(name)
            return name
        elif (not os.path.exists(name+str(i)+'.tex')):
            rename(name+str(i))
            return name
    print(i)
    #check for existed file if not create new one
    
def latexTop(doc):
    doc.append(Command('title', 'This is your matrix'))
    doc.append(Command('date', NoEscape(r'\today')))
    doc.append(NoEscape(r'\maketitle'))
    doc.append(section)
    # Create top section of document contain title, date
    
def latexMiddle(doc):
    #divideZero, x_geText, x_geMatrix, x_bac, x_sol,
    n,a = mc.randomizer()
    apythonArray = mf.numpyToPython(a)
    numpyArray = mf.pythonToNumpy(apythonArray)
    matrix = Matrix(np.array(numpyArray,dtype = int), mtype='b')
    math = Math(data=[matrix])
    doc.append(math)
    doc.append(section2)
    divideZero, x_geText, x_geMatrix, x_bac, x_sol=mc.matrixCalc(n,a)
    #create a matrix from variable a that is pass from python array to numpyarray
    if divideZero == True:
        for i in x_geText:
            for j in i:
                doc.append(bold(j))
            doc.append(NoEscape('\n'))
        doc.append(bold('Divide by Zero'))
        doc.append(NoEscape('\n'))
        doc.append(bold('No Answer'))
        doc.append(NoEscape('\n'))
    # check whether the matrix is divide by zero or not, if yes append No answer
    elif divideZero == False:
    # if no append gaussian elimination
            
        for i in x_geText:
            matrix2 = Matrix(np.array((x_geMatrix[x_geText.index(i)][0],x_geMatrix[x_geText.index(i)][1],x_geMatrix[x_geText.index(i)][2]),dtype = int), mtype='b')
            math2 = Math(data = [matrix2])
            doc.append(math2)
            for j in i:
                doc.append(bold(j))
                doc.append(NoEscape('\n'))
        doc.append(section3)
    # append GE
        for i in x_bac:
            doc.append(bold(i))
            doc.append(NoEscape('\n'))
            doc.append(NoEscape('\n'))
        doc.append(section4)
    # append back substitution
        for i in x_sol:
            doc.append(bold(i))
            doc.append(NoEscape('\n'))
    # append solution
    else:
        doc.append('None')
    
    print(divideZero, 'divide')

def latexButtom(doc):
    doc.generate_tex()
    doc.generate_pdf(clean=True, clean_tex=False,compiler='pdflatex')
    # create tex document
    # create pdf document
  