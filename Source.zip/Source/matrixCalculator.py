# output from matrixCalculator
#
# divideZero, x_geText, x_geMatrix, x_bac, x_sol
#
# divideZero, flag for divide by zero(message includeed in
# final line of GE text)
#
# GE text(double layers array, per rows, per a[i][j])
# x_geText = []
#
# GE matrix(array of matrix array)
# x_geMatrix = []
#
# back subtitution(array of text)
# x_bac = []
#
# final answer(array of text)
# x_sol = []



# Importing Library
import numpy as np
import matrixFormatConverter as converter
import sys

def matrixCalc(n,a):
    n=int(n)
    # Making zeros array of n x n+1 size for storing solution matrix
    x = np.zeros(n)
    
    # divide by zero flag
    divideZero = False
    # Arrays for Solution
    # Gauss Elimination
    x_geText = []
    x_geMatrix = []
    # back subtitution
    x_bac = []
    # answer
    x_sol = []

    # Applying Gauss Elimination
    for i in range(n):
        if a[i][i] == 0.0:
            # divide by zero
            divideZero = True
            x_geText.append('a[%.2f][%.2f] = 0, Divide by zero detected'%(i,i))
            x_geMatrix.append(converter.numpyToPython(a))
            
            return divideZero, x_geText, x_geMatrix, x_bac, x_sol
            
        for j in range(i+1, n):
            ratio = a[j][i]/a[i][i]
            
            # creat rowList array to store list of each row's texts
            rowList = []

            for k in range(n+1):
                a[j][k] = a[j][k] - ratio * a[i][k]

                sol = a[j][k]
                # append array rowList
                rowList.append("a[%d][%d] = a[%d][%d] - (%.2f × a[%d][%d]) = %.2f"%(j,k,j,k,ratio,i,k,sol))
            # append array x_ge
            x_geText.append(rowList)
            x_geMatrix.append(converter.numpyToPython(a))


    # Back Substitution
    x[n-1] = a[n-1][n]/a[n-1][n-1]
    # append array x_bac
    x_bac.append('x[%d] = a[%d][%d] ÷ a[%d][%d] = %d'%(n-1,n-1,n,n-1,n-1,x[n-1]))

    for i in range(n-2,-1,-1):
        x[i] = a[i][n]
        # append array x_bac
        x_bac.append('x[%d] = a[%d][%d] = %.2f'%(i,i,n,x[i]))
        for j in range(i+1,n):
            x[i] = x[i] - a[i][j]*x[j]
            x_bac.append('x[%d] = x[%d] - a[%d][%d] × x[%d]= %.2f'%(i,i,i,j,j,x[i]))
        x[i] = x[i]/a[i][i]
        x_bac.append('x[%d] = x[%d] ÷ a[%d][%d] = %.2f'%(i,i,i,i,x[i]))

    # append array x_sol
    for i in range(n):
        #print('X%d = %0.2f' %(i,x[i]), end = '\t')
        x_sol.append('X%d = %0.2f' %(i,x[i]))
    # return
    return divideZero, x_geText, x_geMatrix, x_bac, x_sol


# return n X n+1 matrix filled with numbers random from a to b
# default 3 x 4 matrix with random numbers from 0 to 20
def randomizer(n = 3,a = 0 ,b = 20):
    a = np.random.randint(a,b,size=(n, n+1))
    # return augmented matrix
    return n,a




