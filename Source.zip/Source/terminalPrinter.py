# for printing in terminal
def terminalPrinter(divideZero, a, x_geText, x_geMatrix, x_bac, x_sol):
    print("--------------\nMatrix:")
    for row in a:
        print(row)
    # displaying step-by-step solution
    print('\nStep-by-step is:\n')

    #divide by zero case
    if divideZero == True:
        for j in x_geText:
            for i in j:
                print(i)
    #normal case - pass along to stepByStep()
    else:
        stepByStepTerminal(x_geText, x_geMatrix, x_bac, x_sol)
    print('----------------')

# for creating and appending txt file
def txtPrinter(divideZero, a, x_geText, x_geMatrix, x_bac, x_sol):
    f = open("matrix solution.txt", "w", encoding="utf-8")
    f.write("\n\n--------------\nMatrix:\n")
    for row in a:
        f.write(str(row)+'\n')
    f.write('\nStep-by-step is:\n')

    #divide by zero case
    if divideZero == True:
        for j in x_geText:
            for i in j:
                f.write(i+'\n')
    #normal case - pass along to stepByStep()
    else:
        stepByStepTxt(x_geText, x_geMatrix, x_bac, x_sol,f)

    f.write("\n--------------")
    f.close()

# isolated step-by- for ease of understanding
def stepByStepTerminal(x_geText, x_geMatrix, x_bac, x_sol):

    print('\nApplying Gauss Elimination')
    for j in x_geText:
        matrix = x_geMatrix[x_geText.index(j)]
        for row in matrix:
            print(row)
        for i in j:
            print(i)
    print('----------------')

    print('Applying Back Substitution')
    for i in x_bac:
        print(i)
    print('----------------')
    
    print('Solution is: ')
    for i in x_sol:
        print(i)

def stepByStepTxt(x_geText, x_geMatrix, x_bac, x_sol,f):
    f.write('\nApplying Gauss Elimination'+'\n')
    for j in x_geText:
        matrix = x_geMatrix[x_geText.index(j)]
        for row in matrix:
            f.write(str(row)+'\n')
        for i in j:
            f.write(i+'\n')
    f.write('----------------'+'\n')
    f.write('Applying Back Substitution'+'\n')
    for i in x_bac:
        f.write(i+'\n')
    f.write('----------------'+'\n')
    f.write('Solution is: '+'\n')
    for i in x_sol:
        f.write(i+'\n')